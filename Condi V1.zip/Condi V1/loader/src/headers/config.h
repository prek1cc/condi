#pragma once

#define HTTP_SERVER "YOURIP"
#define HTTP_PORT 80

#define TFTP_SERVER "YOURIP"
